# Library Usage Analytics

A college-level data analytics project analysing book circulation, borrowing trends, member activity, and category preferences for a college library. Built as part of an IBM SkillsBuild Data Analytics project.

---

## Project Overview

This project examines 20 borrowing records from January to April 2026, covering book circulation patterns, popular categories, member engagement, and seasonal borrowing trends.

---

## Project Structure

```
Library-Usage-Analytics/
│
├── data/
│   ├── library_usage_data.xlsx     # Main dataset (Circulation Data + Analytics Summary sheets)
│   └── library_usage_data.csv      # CSV export of the dataset
│
├── analysis/
│   └── library_usage_analysis.xlsx # Detailed analysis workbook (5 sheets with charts)
│
├── charts/                          # Placeholder for exported chart images
│
├── docs/
│   ├── project_report.md           # Full project report (10 sections)
│   └── project_summary.md          # One-page executive summary
│
├── README.md
├── .gitignore
└── bob_prompt.txt
```

---

## Dataset

| Column | Description |
|---|---|
| Borrowing ID | Unique identifier (BRW001–BRW020) |
| Book Title | Title of the borrowed book |
| Category | Technology / Fiction / Self Help / Biography / Finance / History |
| Member ID | Unique member identifier (M101–M110) |
| Member Type | Student or Faculty |
| Borrow Date | Date the book was borrowed |
| Return Date | Date the book was returned |
| Days Borrowed | Number of days the book was kept |
| Status | Returned or Borrowed (active) |

**Date range:** January 2026 – April 2026  
**Records:** 20  
**Members:** 10 (7 Students, 3 Faculty)

---

## Analysis Areas

1. Book circulation (total records, return rate)
2. Most borrowed books
3. Borrowing by category
4. Member borrowing activity
5. Student vs Faculty borrowing comparison
6. Monthly borrowing trends
7. Average days borrowed
8. Key findings and insights

---

## Key Findings

- **Technology** is the most borrowed category (25% of all borrowings)
- **January** had the highest borrowing activity (8 records, 40%)
- All 10 members borrowed equally — 2 books each
- Students account for **70%** of total borrowing activity
- Average loan duration: **15.7 days**
- Return rate: **95%** (19 of 20 records returned)

---

## Tools Used

- Microsoft Excel (data storage, analysis, charts)
- CSV (data export)
- Markdown (documentation)

---

## How to Use

1. Open `data/library_usage_data.xlsx` to explore the raw dataset and summary statistics
2. Open `analysis/library_usage_analysis.xlsx` to review the detailed analysis sheets and charts
3. Read `docs/project_report.md` for the full written report
4. Read `docs/project_summary.md` for a quick overview

---

## Acknowledgements

This project was completed as part of the IBM SkillsBuild Data Analytics programme.
